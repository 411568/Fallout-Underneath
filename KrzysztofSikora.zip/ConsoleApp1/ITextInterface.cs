using System.Runtime.CompilerServices;
using System.Text;


namespace FalloutUnderneath
{
    public interface ITextInterface
    {
        public void WriteOnTextInterface(ScreenTextInterface textInterface);
    }
}